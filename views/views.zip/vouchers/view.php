<?php if($this->global_setting->brand_logo){ 
			$schoollogo=  UPLOAD_PATH.'logo/'.$this->global_setting->brand_logo; 
	} else { 
	$schoollogo=  IMG_URL. '/sms-logo-50.png';
	 } 		
	?> 
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-home"></i><small> <?php echo $this->lang->line('voucher'); ?></small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>                    
                </ul>
                <div class="clearfix"></div>
            </div>             
            <div class="x_content quick-link no-print">
				<?php $this->load->view('quicklinks/account'); ?>
			</div>
            <div class="x_content">
			<div class="row no-print">
                <div class="col-xs-12 text-right">				
                    <button class="btn btn-default " onclick="window.print();"><i class="fa fa-print"></i> <?php echo $this->lang->line('print'); ?></button>
                </div>
            </div>			
			<div id='pageCnt'>
			<div class="row print-only">				
				<div style=""><span style=""><img width="65px" src="<?php print $schoollogo; ?>" style="max-width:25px;" /></span><span style="padding-top:40px;padding-left:20px;font-size:28px;font-weight:bold;"><?php print $school_info->school_name; ?></span></div><div><h3><?php print $voucher->name; ?> Entries</h3></div>		
			</div>
			<div class='row'>
			<div class='col-md-12'>
			<table id="table2" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0">                               
                                <tbody>                                     
                                        <tr>
											<th width="30%"><?php echo $this->lang->line('name'); ?></th>
											<td><?php echo $voucher->name; ?></td>
                                        </tr>
										<tr>
											<th width="30%"><?php echo $this->lang->line('school'); ?></th>
											<td><?php echo $voucher->school_name; ?></td>
                                        </tr>
										<tr>
											<th width="30%"><?php echo $this->lang->line('type'); ?></th>
											<td><?php echo $voucher->type_name; ?></td>
                                        </tr>
										<tr>
											<th width="30%"><?php echo $this->lang->line('is_readonly'); ?>?</th>
											<td><?php if($voucher->is_readonly == 1) echo 'Yes'; else echo 'No'; ?></td>
                                        </tr>
										<tr>
											<th width="30%"><?php echo $this->lang->line('budget'); ?></th>
											<td><?php echo $voucher->budget." [".$voucher->budget_cr_dr."]"; ?></td>
                                        </tr>										
										<tr>
											<th width="30%"><?php echo $this->lang->line('academic_year'); ?></th>
											<td><?php echo $voucher->session_year; ?></td>
                                        </tr>
                                      
                                </tbody>
                            </table>  
			</div>
			</div>
			<div class='row'>
				<div class='col-md-12 col-sm-12 col-xs-12'>
					<h5 class="column-title"><strong>Entries:</strong>
					<?php if($voucher->is_readonly == 0){ ?>
					<span class='hidePrint no-print' style='text-align:right;float:RIGHT;'><a class="btn btn-primary" style="text-align:right;" href="<?php echo site_url('transactions/create/'.$voucher->id); ?>">New Entry</a></span>
					<?php } ?>
					</h5>
				</div>
				<div class='col-md-12 col-sm-12 col-xs-12'>
				<table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0">                               
                                <thead> 
								 <tr>
                                        <th><?php echo $this->lang->line('sl_no'); ?></th>
                                        <th><?php echo $this->lang->line('transaction_no'); ?></th>
										<th><?php echo $this->lang->line('date'); ?></th>
										<th><?php echo $this->lang->line('head_ledger'); ?></th>
										<th><?php echo $this->lang->line('dr_cr'); ?></th>
										<th><?php echo $this->lang->line('total_amount'); ?></th>
                                        <th class='no-print'><?php echo $this->lang->line('action'); ?></th>
                                    </tr>
									  </thead>
                                <tbody>   
                                    <?php $count = 1; if(isset($transactions) && !empty($transactions)){ ?>
                                        <?php $total_amount=0;
										foreach($transactions as $obj){ 
										if($obj->cancelled==0){
										$total_amount += $obj->total_amount; } ?>
                                        <tr<?php if($obj->cancelled != 0){ print " class='strikeRow'"; } else { print " class='dataRow'"; } ?>>
                                            <td><?php echo $count++; ?></td>
											<td><?php echo $obj->transaction_no; ?></td>
											<td><?php echo date('d-m-Y',strtotime($obj->date)); ?></td>
											<td><a href="<?php echo site_url('/accountledgers/view/'.$obj->ledger_id); ?>"><?php echo $obj->ledger_name; ?></a></td>
											<td><?php echo $obj->head_cr_dr; ?></td>
											<td class='amount' align='right'><?php echo $obj->total_amount; ?></td>
											<td class='no-print'>
											<?php if(has_permission(VIEW, 'accounting', 'accounttransactions')){ ?>
                                                        <a href="<?php echo site_url('transactions/view/'.$obj->id); ?>"  class="btn btn-success btn-xs"><i class="fa fa-eye"></i> <?php echo $this->lang->line('view'); ?> </a>
                                                    <?php } ?>
													</td>
										</tr>
									<?php } } ?>
								</tbody>
								<tfoot>
								<tr>
									<th></th>
									<th></th>
									<th></th>
									<th></th>
									<th>Total Amount</th>
									<th class="totalAmt" align="right" style="text-align:right;"><?php print $total_amount; ?></th>
									<th class='no-print'></th>
								</tr>
								</tfoot>
								</table>
				</div>
			</div>
</div>			
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
<?php /* if(isset($school_info->frontend_logo) && $school_info->frontend_logo!= ''){ ?>
				var schoollogo= '<?php print UPLOAD_PATH."/logo/".$school_info->frontend_logo; ?>';
	<?PHP } else*/ if($this->global_setting->brand_logo){ ?> 
			var schoollogo=  '<?php echo UPLOAD_PATH.'logo/'.$this->global_setting->brand_logo; ?>';
	<?php } else {  ?>
	var schoollogo=  "<?php echo IMG_URL. '/sms-logo-50.png'; ?>";
	<?php } 	
		$text_bottom="";
	
	?> 
    $(document).ready(function() {		
		$('#datatable-responsive thead tr').clone(true).appendTo( '#datatable-responsive thead' );
		$('#datatable-responsive thead tr:eq(1)').addClass("no-print");
		$('#datatable-responsive thead tr:eq(1) th').each( function (i) {
			var title = $(this).text();		
				if(title == 'Action'){				
					$(this).html( '' );	
				}
				else{
					$(this).html( '<input type="text" placeholder="Search" style="width:100%;"  class="column_search" />' );	
				}
		         
		} );
		//$('#datatable-responsive thead').find('input[id^=datepicker]').datepicker();	
	
		jQuery.fn.dataTable.Api.register( 'sum()', function ( ) {		
			return this.flatten().reduce( function ( a, b ) {						
				if ( typeof a === 'string' ) {
					a = a.replace(/[^\d.-]/g, '') * 1;
				}
				if ( typeof b === 'string' ) {
					b = b.replace(/[^\d.-]/g, '') * 1;
				}  
				return a + b; 
			}, 0 );
			
		} );
          var table =$('#datatable-responsive').DataTable( {
              dom: 'Brtip',
			  destroy: true,
			  "info": false,
			  orderCellsTop: true,
				fixedHeader: true,
              iDisplayLength: 15,
			  drawCallback: function () {				  
				  var api = this.api();	
				  var total_amount=0;
				  var val=0;
				  $("#datatable-responsive .dataRow .amount").each(function(){
					  val= $(this).html();
					  
					  total_amount = total_amount + parseInt(val);
				  });
				  $("th.totalAmt" ).html(total_amount);
				  /*$("th.totalAmt" ).html(				  
					api.column( 5, {page:'current'} ).data().sum()
				  );*/							
			  },
              buttons: [
                  'copyHtml5',
                  'excelHtml5',
                  'csvHtml5',
                  'pdfHtml5',
                  'pageLength',
				  'colvis',
				  {
					  
					'extend': 'print',
					title: '<div style=""><span style=""><img width="65px" src="'+schoollogo+'" style="max-width:25px;" /></span><span style="padding-top:40px;padding-left:20px;"><?php print $school_info->school_name; ?></span></div><div><h3><?php print $voucher->name; ?> Entries</h3></div>',	
					footer: true,					
					exportOptions: {
                     columns: 'thead th:not(.no-print)'
					},
					customize: function ( win ) {
						$(win.document.body).css( 'margin', '20px' );						 
					}
					
				}
              ],
			 /* "columnDefs": [
					{
						"targets": [ 8 ],
						"visible": false,
						"searchable": true
					},
					{
						"targets": [ 9 ],
						"visible": false,
						"searchable": true
					}
				],*/
              //searching: false, 
			  search:true,
			  ordering: false,			  
              responsive: true
          });
		   $( '#datatable-responsive thead .column_search'  ).bind( 'keyup change', function () {   
        table
            .column( $(this).parent().index() )
            .search( this.value )
            .draw();
    } );		
        });
function printDiv(divName) {
     var printContents = "<div><h2><?php print $accountledger->school_name; ?></h2></div><div><h3><?php print $accountledger->name; ?> Entries</h3></div>";
	 printContents += document.getElementById(divName).innerHTML;
	 printContents += "<style>#datatable-responsive thead tr:nth-child(2), .dataTables_paginate,.hidePrint{display: none;}</style>";
    var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;	  
}		
</script>	