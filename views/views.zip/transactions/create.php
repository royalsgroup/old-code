<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-home"></i><small> <?php echo $this->lang->line('add')." ".$this->lang->line('entry')." - ".$voucher->name; ?></small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>                    
                </ul>
                <div class="clearfix"></div>
            </div>             
            
            <div class="x_content">
                 <?php echo form_open_multipart(site_url('transactions/create'), array('name' => 'add', 'id' => 'add', 'class'=>'form-horizontal form-label-left'), ''); ?>
				 <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line('date'); ?> <span class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">										
										  <input type="text" class="form-control date col-md-7 col-xs-12" id="date" name="date" required='required' autocomplete="off">   
                                        <div class="help-block"><?php echo form_error('date'); ?></div>
                                    </div>
                                </div> 
								<div class="item form-group">                        
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line('ledger'); ?><span class="required">*</span></label>
											 <div class="col-md-6 col-sm-6 col-xs-12">
											 <?php if($voucher->type_id == 1){
												 $ledger_input_name="ledger_id[]";
											 }
											 else{
												$ledger_input_name="ledger_id"; 
											 }?>
                                           <select autofocus="" id="ledger_id" name="<?php print $ledger_input_name; ?>" class="form-control select2" required='required' >
                                        <option value=""><?php echo $this->lang->line('select'); ?></option>
                                        <?php
                                        foreach ($ledgers as $ledger) {
                                            ?>
                                            <option value="<?php echo $ledger->id ?>"<?php
                                            if (isset($_POST['ledger_id']) && $_POST['ledger_id'] == $ledger->id) {
                                                echo "selected = selected";
                                            }
                                            ?>><?php echo $ledger->name." [".$ledger->effective_balance_cr_dr." : ".$ledger->effective_balance."]"; ?></option>

                                            <?php
                                        }
                                        ?>
										</select>
                                            <div class="help-block"><?php echo form_error('ledger_id'); ?></div> 
                                        </div>
                                    </div>
									<?php 
									if($voucher->type_id ==1){ // journal voucher ?>
									<div class="row" id='multipleHead'>
									</div>
									<div class="item form-group">
									 <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"></label>
									  <div class="col-md-6 col-sm-6 col-xs-12">
									<a href="javascript:void(0);" class='btn btn-default' onclick="add_head()"> ADD</a>
									</div>
									</div>
									<?php } ?>
									<div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line('head_cr_dr'); ?><span class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
									<select required='required' name='head_cr_dr' class="form-control col-md-7 col-xs-12">
										<option value='CR'>CR</option>
										<option value='DR'>DR</option>
									</select>
									</div>
									</div>
									<div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line('narration'); ?>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
									<textarea class="form-control col-md-7 col-xs-12" id="narration" name="narration" autocomplete="off"></textarea>                                        
                                        <div class="help-block"><?php echo form_error('narration'); ?></div>
                                    </div>
                                </div>
								<div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line('particulars'); ?>
                                    </label>
                                    <div class="col-md-9 col-sm-9 col-xs-12">
										<table class='table particulars'>
											<thead>
												<tr>
													<td><?php echo $this->lang->line('ledger'); ?></td>
													<td><?php echo $this->lang->line('amount'); ?></td>
													<td><?php echo $this->lang->line('remark'); ?></td>
													<td></td>
												</tr>
											</thead>
											<tbody>
											</tbody>
											<tfoot>
												<tr>
													<td><a href="javascript:void(0);" class='btn btn-default' onclick="add_particulars()"> ADD</a></td>
												</tr>
											</tfoot>
										</table>
									</div>
								</div>
								<div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line('total'); ?>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
										<input type='text' id="total_amount" name='total_amount' disabled value='' />
									</div>
								</div>
								 <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
										<input type='hidden' name='voucher_id' value='<?php print $voucher->id; ?>' />
                                        <a href="<?php echo site_url('vouchers/view/'.$voucher->id); ?>" class="btn btn-primary"><?php echo $this->lang->line('cancel'); ?></a>
                                        <button id="send" type="submit" class="btn btn-success"><?php echo $this->lang->line('submit'); ?></button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<link href="<?php echo VENDOR_URL; ?>datepicker/datepicker.css" rel="stylesheet">
 <script src="<?php echo VENDOR_URL; ?>datepicker/datepicker.js"></script>
   <!-- bootstrap-datetimepicker -->
   <script src="<?php echo base_url(); ?>assets/js/moment.min.js"></script>
   <link rel="stylesheet" href="<?php echo base_url(); ?>assets/datepicker/css/bootstrap-datetimepicker.css">
 <script src="<?php echo base_url(); ?>assets/datepicker/js/bootstrap-datetimepicker.js"></script>
 <script type="text/javascript">
 var count=0; 
    $(document).ready(function () {
		 var date_format = '<?php echo $result    = strtr('m/d/Y', ['d' => 'dd', 'm' => 'mm', 'Y' => 'yyyy']) ?>';
       var date_format_js = '<?php echo $result = strtr('m/d/Y', ['d' => 'dd', 'm' => 'MM', 'Y' => 'yyyy']) ?>';        
		$('.date').datepicker({
            format: date_format,
			//startDate:new Date(),
             autoclose: true,
                language: '<?php echo $language_name ?>'
        }); 
		
		add_particulars();		
	});
	function cal_total_amount(){
			var total_amount=0;
		$('table.particulars td .pamount').each(function() {
				if($(this).val()!= ''){
					total_amount= parseInt(total_amount) + parseInt($(this).val());			
				}
		});
		$("input#total_amount").val(total_amount);
	}
	function add_particulars(){
		var html='';
		html += '<tr id="row'+count+'">';
		html += "<td><select class='form-control select21' name='pledger["+count+"]'><option value=''>--Select--</option>";
		<?php  foreach ($ledgers as $ledger) { ?>
			html += "<option value='<?php print $ledger->id; ?>'><?php print $ledger->name.' ['.$ledger->effective_balance_cr_dr.' : '.$ledger->effective_balance.']'; ?></option>";
		<?php } ?>
		html += "</select></td>";
		html += "<td><input type='text' class='form-control pamount' name='pamount["+count+"]'  onkeyup='cal_total_amount();' /></td>";
		html += "<td><input type='text' class='form-control' name='premark["+count+"]' /></td>";
		html += "<td><a href='javascript:void(0);' class='btn btn-danger' onclick='remove_particular("+count+");'>Remove</a></td>";
		html += '</tr>';		
		$("table.particulars tbody").append(html);
		count++;
		$('.select21').select2();
	}
	function remove_particular(index){
		var rowCount = $('table.particulars tbody >tr').length;		
		if(rowCount >1){
			$("tr#row"+index).remove();
			cal_total_amount();
		}
	}
	function add_head(){
		//var ledger_data=$("#ledger_id").html();		
		var html='';
		html += '<div class="item form-group">';
		html += '<label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line("ledger"); ?></label>';
		html += '<div class="col-md-6 col-sm-6 col-xs-12">';
		html += '<select class="form-control select22" name="ledger_id[]">';
		html += '<option value="">--Select--</option>';
		<?php  foreach ($ledgers as $ledger) { ?>
			html += "<option value='<?php print $ledger->id; ?>'><?php print $ledger->name.' ['.$ledger->effective_balance_cr_dr.' : '.$ledger->effective_balance.']'; ?></option>";
		<?php } ?>
		html += "</select></div></div>";
		
		//html += "<td><a href='javascript:void(0);' class='btn btn-danger' onclick='remove_particular("+count+");'>Remove</a></td>";
		//html += '</tr>';		
		$("#multipleHead").append(html);		
		$('.select22').select2();
	}
	
	</script>
	