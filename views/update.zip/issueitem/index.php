<style>
.miplus {
    position: absolute;
    width: 60px;
}
.miplus select {
    height: 28px;
    padding-left: 10px;
}
#item_unit{
	font-weight:normal;
}
.miplusinput {
    padding-left: 70px;
}
.list2 li span {
    width: 70%;
    float: right;
    padding-left: 10px;    
    font-weight: normal;
</style>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-home"></i><small> <?php echo $this->lang->line('manage_item')." ".$this->lang->line('issue'); ?></small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>                    
                </ul>
                <div class="clearfix"></div>
            </div>             
            
            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">
                    
                    <ul  class="nav nav-tabs bordered">
                        <?php if(has_permission(VIEW, 'inventory', 'issueitem')){ ?>
                        <li class="<?php if(isset($list)){ echo 'active'; }?>"><a href="#tab_itemissue_list"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-list-ol"></i> <?php echo $this->lang->line('item')." ".$this->lang->line('issueitem'); ?> <?php echo $this->lang->line('list'); ?></a> </li>
                       <?php } ?>
                       
                       <?php if(has_permission(ADD, 'inventory', 'issueitem')){ ?> 
                            <?php if(isset($edit)){ ?>
                                <li  class="<?php if(isset($add)){ echo 'active'; }?>"><a href="<?php echo site_url('issueitem/add'); ?>"  aria-expanded="false"><i class="fa fa-plus-square-o"></i> <?php echo $this->lang->line('issue')." ".$this->lang->line('item'); ?></a> </li>                          
                             <?php }else{ ?>
                                <li  class="<?php if(isset($add)){ echo 'active'; }?>"><a href="#tab_add_itemissue"  role="tab"  data-toggle="tab" aria-expanded="false"><i class="fa fa-plus-square-o"></i> <?php echo $this->lang->line('issue')." ".$this->lang->line('item'); ?></a> </li>                          
                             <?php } ?>
                        <?php } ?>                       
                            
                        <?php if(isset($edit)){ ?>
                            <li  class="active"><a href="#tab_edit_itemissue"  role="tab"  data-toggle="tab" aria-expanded="false"><i class="fa fa-pencil-square-o"></i> <?php echo $this->lang->line('edit'); ?> <?php echo $this->lang->line('item'); ?></a> </li>                          
                        <?php } ?> 
						 <li class="li-class-list">
                       <?php if($this->session->userdata('role_id') == SUPER_ADMIN || $this->session->userdata('role_id') == DISTRICT_ADMIN){  ?>                                 
                            <select  class="form-control col-md-7 col-xs-12" onchange="get_itemissue_by_school(this.value);">
                                    <option value="<?php echo site_url('issueitem/index'); ?>">--<?php echo $this->lang->line('select'); ?> <?php echo $this->lang->line('school'); ?>--</option> 
                                <?php foreach($schools as $obj ){ ?>
                                    <option value="<?php echo site_url('issueitem/index/'.$obj->id); ?>" <?php if(isset($filter_school_id) && $filter_school_id == $obj->id){ echo 'selected="selected"';} ?> > <?php echo $obj->school_name; ?></option>
                                <?php } ?>   
                            </select>
                        <?php } ?>  
                    </li> 
                    </ul>
                    <br/>
                    
                    <div class="tab-content">
                        <div  class="tab-pane fade in <?php if(isset($list)){ echo 'active'; }?>" id="tab_itemissue_list" >
                            <div class="x_content">
                            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th><?php echo $this->lang->line('sl_no'); ?></th>
										<?php if($this->session->userdata('role_id') == SUPER_ADMIN || $this->session->userdata('role_id') == DISTRICT_ADMIN){ ?>
										<th><?php echo $this->lang->line('school'); ?></th>
										<?php } ?>
                                        <th><?php echo $this->lang->line('item'); ?></th>  
										<th><?php echo $this->lang->line('category'); ?></th>
										<th><?php echo $this->lang->line('issue_return'); ?></th>
										<th><?php echo $this->lang->line('issue_to'); ?></th>
										<th><?php echo $this->lang->line('issue_by'); ?></th>
                                        <th><?php echo $this->lang->line('issue_price'); ?>Price</th>
										<th><?php echo $this->lang->line('quantity'); ?></th>										
										<th><?php echo $this->lang->line('status'); ?></th>
                                        <th><?php echo $this->lang->line('action'); ?></th>                                            
                                    </tr>
                                </thead>
                                <tbody>   
                                    <?php $count = 1; if(isset($itemissue) && !empty($itemissue)){ ?>
                                        <?php foreach($itemissue as $obj){ ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
											<?php if($this->session->userdata('role_id') == SUPER_ADMIN || $this->session->userdata('role_id') == DISTRICT_ADMIN){ ?>
											<td><?php echo $obj['school_name']; ?></td>
											<?php } ?>
                                            <td><?php echo $obj['item_name']; ?></td>
											<td><?php echo $obj['item_category']; ?></td>
											<td><?php 
											if($obj['return_date'] != null){
											echo date('d-m-Y',strtotime($obj['return_date'])); } ?></td>
											<td><?php echo $obj['to_user']; ?></td>
											<td><?php echo $obj['by_user']; ?></td>
                                            <td><?php echo $obj['issue_price']; ?></td>
											<td><?php echo $obj['quantity']; ?></td>
											<td>
											<?php if ($obj['is_returned'] == 0) {
                                                        ?>


                                                        <span class="label label-danger item_remove" data-item="<?php echo $obj['id'] ?>" data-category="<?php echo $obj['item_category'] ?>" data-item_name="<?php echo $obj['item_name'] ?>" data-quantity="<?php echo $obj['quantity'] ?>" data-toggle="modal" data-target="#confirm-delete"><?php echo $this->lang->line('click_to_return'); ?></span>

                                                    <?php  } else if($obj['is_returned'] == 2) { ?>

                                                  <span class="label label-danger" 
                                                 <?php echo $this->lang->line('Sell'); ?>>Sell</span> 

                                                   <?php }else { ?>

                                                        <span class="label label-success"><?php echo $this->lang->line('returned'); ?></span>

                                                        <?php
                                                    }
                                                    ?>
											</td>											
                                            <td>                                                                                                
                                                <?php if(has_permission(DELETE, 'inventory', 'issueitem')){ ?>
                                                    <a href="<?php echo site_url('/issueitem/delete/'.$obj['id']); ?>" onclick="javascript: return confirm('<?php echo $this->lang->line('confirm_alert'); ?>');" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> <?php echo $this->lang->line('delete'); ?> </a>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    <?php } ?>
                                </tbody>
                            </table>                                
                            </div>
                        </div>

                        <div  class="tab-pane fade in <?php if(isset($add)){ echo 'active'; }?>" id="tab_add_itemissue">
                            <div class="x_content"> 
                               <?php echo form_open_multipart(site_url('issueitem/add'), array('name' => 'add', 'id' => 'add', 'class'=>'form-horizontal form-label-left'), ''); ?>                                                                                              <?php $this->load->view('layout/school_list_form'); ?>     
                                <div class="item form-group">                        
                                    
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line('user_type'); ?> <span class="required">*</span></label>
											<div class="col-md-6 col-sm-6 col-xs-12">
                                             <select name="issue_type" onchange="getIssueUser(this.value)"  id="issue_type" class="form-control ac_type">
                                        <option value=""><?php echo $this->lang->line('select'); ?></option>
                                        <?php
                                        foreach ($roles as $role_key => $role_value) {
                                            ?>                
                                            <option value="<?php echo $role_value->id; ?>"><?php echo $role_value->name; ?></option>

                                            <?php echo $role_value->name; ?>


                                            <?php
                                        }
                                        ?>

                                    </select>
                                            <div class="help-block"><?php echo form_error('account_type'); ?></div> 
                                        </div>
                                    </div>                                                                      
								
								 <div class="item form-group">                        
                                    
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line('issue_to'); ?> <span class="required">*</span></label>
											<div class="col-md-6 col-sm-6 col-xs-12">
										<select  id="issue_to" name="issue_to" class="form-control">
                                        <option value=""><?php echo $this->lang->line('select'); ?></option>
                                    </select>
										 <div class="help-block"><?php echo form_error('issue_to'); ?></div> 
                                        </div>
                                    </div>                                                                      
								 
								 <div class="item form-group">                        
                                    
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line('issue_date'); ?> 
                                    </label>
                                   <div class="col-md-6 col-sm-6 col-xs-12">
										<input type="text" class="form-control date col-md-7 col-xs-12" id="date" name="issue_date" autocomplete="off" value="<?php echo isset($itemissue['issue_date']) ?  date('m/d/Y',strtotime($itemissue['issue_date'])) : ''; ?>">										     
                                        <div class="help-block"><?php echo form_error('issue_date'); ?></div>
                                   
                                </div>
                                    </div>    

                                         <div class="item form-group">                        
                                    
                                           <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line('issue_type'); ?>Issue Type</label>  
                                             </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select  id="issue_type" name="issue_type" class="form-control">
                                        <option value="0"><?php echo $this->lang->line('select'); ?></option>
                                        <option value="2"><?php echo $this->lang->line('sell'); ?>Sell</option>
                                        <option value="1"><?php echo $this->lang->line('return'); ?></option>
                                    </select>
                                         <div class="help-block"><?php echo form_error('issue_to'); ?></div> 
                                        </div>
                                    </div>

								
								 <div class="item form-group">                        
                                    
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line('return_date'); ?> 
                                             </label>
                                           <div class="col-md-6 col-sm-6 col-xs-12">
        										<input type="text" class="form-control date col-md-7 col-xs-12" id="date" name="return_date" autocomplete="off" value="<?php echo isset($itemissue['return_date']) ?  date('m/d/Y',strtotime($itemissue['return_date'])) : ''; ?>">										     
                                                <div class="help-block"><?php echo form_error('return_date'); ?></div>
                                           
                                        </div>
                                    </div>                                                                      
								
 <div class="item form-group">                        
                                    
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line('note'); ?></label>
											<div class="col-md-6 col-sm-6 col-xs-12">
											<textarea name='note' class="form-control col-md-7 col-xs-12"><?php echo isset($itemissue['note']) ?  $itemissue['note'] : ''; ?></textarea>                                          
                                            <div class="help-block"><?php echo form_error('note'); ?></div> 
                                        </div>
                                    </div>                                                                      
								
 <div class="item form-group">                        
                                    
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line('category'); ?> <span class="required">*</span></label>
											<div class="col-md-6 col-sm-6 col-xs-12">
                                            <select autofocus="" id="item_category_id" name="item_category_id" class="form-control" required='required' >
                                        <option value=""><?php echo $this->lang->line('select'); ?></option>
                                         <?php
                                        foreach ($itemcategories as $item_category) {
                                            ?>
                                            <option value="<?php echo $item_category->id ?>"<?php
                                            if (isset($_POST['item_category_id']) && $_POST['item_category_id'] == $item_category->id) {
                                                echo "selected = selected";
                                            }
                                            ?>><?php echo $item_category->item_category ?></option>

                                            <?php
                                        }
                                        ?>
                                    </select>
                                            <div class="help-block"><?php echo form_error('item_category_id'); ?></div> 
                                        </div>
                                    </div>                                                                      
								
								<!--   <div class="item form-group">                        
                                    
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line('item'); ?> <span class="required">*</span></label>
											<div class="col-md-6 col-sm-6 col-xs-12">
                                    <select  id="item_id" name="item_id" class="form-control"  required='required'  size="5" multiple >
                                        <option value=""><?php echo $this->lang->line('select'); ?></option>

                                    </select>
                                    <span class="text-danger"><?php echo form_error('item_id'); ?></span>
										</div>
                                    </div>   -->                                                                    
										
                    <!-- <div class="item form-group">                        
                                    
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line('quantity'); ?> <span class="required">*</span></label>
											<div class="col-md-6 col-sm-6 col-xs-12">
                                            <div class="">                                     
                                        <input id="quantity" name="quantity" placeholder="" type="text" class="form-control "  value="<?php echo isset($_POST['quantity']) ?  $_POST['quantity'] : ''; ?>" required="required" />
										<div id="div_avail">
                                                <span>Available Quantity : </span>
                                                <span id="item_available_quantity">0</span>
                                            </div>
                                    </div>
                                            <div class="help-block"><?php echo form_error('quantity'); ?></div> 
                                        </div>
                                    </div>   -->


                                      <div id="addCommissionForm"></div>                                                                    
															
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <a href="<?php echo site_url('itemissue/index'); ?>" class="btn btn-primary"><?php echo $this->lang->line('cancel'); ?></a>
                                        <button id="send" type="submit" class="btn btn-success"><?php  echo $this->lang->line('submit'); ?></button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>  
</div>
                    
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">

                <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('confirm_return'); ?></h4>
            </div>

            <div class="modal-body">
                <input type="hidden" id="item_issue_id" name="item_issue_id" value="">
                <p>Are you sure to return this item !</p>

                <ul class="list2">
                    <li><?php echo $this->lang->line('item'); ?><span id="modal_item"></span></li>
                    <li><?php echo $this->lang->line('item_category'); ?><span id="modal_item_cat"></span></li>
                    <li><?php echo $this->lang->line('quantity'); ?><span id="modal_item_quantity"></span></li>
                </ul>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('cancel'); ?></button>
                <a class="btn btn-success cfees btn-ok" data-loading-text="<i class='fa fa-spinner fa-spin '></i> Please Wait.."><?php echo $this->lang->line('return'); ?></a>
            </div>
        </div>
    </div>
</div>
<script type='text/javascript'>
$(document).ready(function () {
        $('#confirm-delete').on('show.bs.modal', function (e) {
            $('#item_issue_id').val("");
            $('.debug-url').html('');
            $('#modal_item_quantity,#modal_item,#modal_item_cat').text("");
            var item_issue_id = $(e.relatedTarget).data('item');
            var item_category = $(e.relatedTarget).data('category');
            var quantity = $(e.relatedTarget).data('quantity');
            var item_name = $(e.relatedTarget).data('item_name');
            $('#item_issue_id').val(item_issue_id);
            $('#modal_item_cat').text(item_category);
            $('#modal_item').text(item_name);
            $('#modal_item_quantity').text(quantity);

        });
        $("#confirm-delete").modal({
            backdrop: false,
            show: false

        });
		 });
		 $(document).on('click', '.btn-ok', function () {
        var $this = $('.btn-ok');
        $this.button('loading');
        var item_issue_id = $('#item_issue_id').val();
        $.ajax(
                {
                    url: "<?php echo site_url('issueitem/returnItem') ?>",
                    type: "POST",
                    data: {'item_issue_id': item_issue_id},
                    dataType: 'Json',
                    success: function (data, textStatus, jqXHR)
                    {
                        if (data.status == "fail") {

                            errorMsg(data.message);
                        } else {
                            successMsg(data.message);
                            //  $("span[data-item='" + item_issue_id + "']").removeClass("label-danger").addClass("label-success").text("Returned");

                            $("#confirm-delete").modal('hide');
                            location.reload();
                        }

                        $this.button('reset');
                    },
                    error: function (jqXHR, textStatus, errorThrown)
                    {
                        $this.button('reset');
                    }
                });

    });
	function successMsg(msg) {
     toastr.success(msg);
 }
    
 function errorMsg(msg) {
     toastr.error(msg);
 }
</script>
<link href="<?php echo VENDOR_URL; ?>datepicker/datepicker.css" rel="stylesheet">
 <script src="<?php echo VENDOR_URL; ?>datepicker/datepicker.js"></script>
 <script type="text/javascript">   
var base_url = '<?php echo base_url() ?>';
    $(document).ready(function() {
		 
		 <?php 
		if(isset($_POST['item_id']))
		{
			$item_id_post = $_POST['item_id'];
		}
		else if(isset($itemstock['item_id'])){
			$item_id_post =$itemstock['item_id'];
		}
		else{
			$item_id_post =0;
		}
		?>
		var item_id_post=<?php echo $item_id_post; ?>;
		 //var item_id_post = '<?php echo isset($_POST['item_id'])? $_POST['item_id']: 0; ?>';
        item_id_post = (item_id_post != "") ? item_id_post : 0;
		<?php 
		if(isset($_POST['item_category_id']))
		{
			$item_category_id_post =$_POST['item_category_id'];
		}
		else if(isset($itemstock['item_category_id'])){
			$item_category_id_post =$itemstock['item_category_id'];
		}
		else{
			$item_category_id_post =0;
		}
		?>
		var item_category_id_post = <?php echo $item_category_id_post; ?>;
        //var item_category_id_post = '<?php echo isset($_POST['item_category_id'])? $_POST['item_category_id']: 0; ?>';
        item_category_id_post = (item_category_id_post != "") ? item_category_id_post : 0;
        populateItem(item_id_post, item_category_id_post);
		<?php if(isset($add)){
			$form_id="form#add ";
		}
		else if(isset($edit)){
			$form_id="form#edit ";
		}
		?>
		var form_id='<?php echo $form_id; ?>';
        function populateItem(item_id_post, item_category_id_post) {
            if (item_category_id_post != "") {
                $(form_id+'#item_id').html("");

               var $addCommissionForm = $('#addCommissionForm');
                var div_data = '<option value=""><?php echo $this->lang->line('select'); ?></option>';
                $.ajax({
                    type: "GET",
                    url: base_url + "itemstock/getItemByCategory",
                    data: {'item_category_id': item_category_id_post},
                    dataType: "json",
                    success: function (data) {
                        $.each(data, function (i, obj)
                        {
                            var select = "";
                            if (item_id_post == obj.id) {
                                var select = "selected=selected";
                            }
                            div_data += "<option value=" + obj.id + " " + select + ">" + obj.name + "</option>";
                             
                               $.ajax({
                              url: base_url + "itemstock/addCommissionForm",
                               type: 'POST',
                              data: {"aepsCommissionForm": onload, "<?php echo $this->security->get_csrf_token_name(); ?>": "<?php echo $this->security->get_csrf_hash(); ?>"},
                              beforeSend: function(){
                                $addCommissionForm.html('<img src="<?php echo base_url("optimum/greay-loading.svg") ?>"/>');
                              },
                              success: function(data) {
                                $addCommissionForm.append(data);

                                $(document).on('click', '#harry1', function (e) {

                                              var element = ' <div class="item form-group"> ';
                                              element += ' <div class="item form-group"> ';
                                              element += '<label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line('item'); ?><span class="required">*</span></label>';
                                              element += '<div class="col-md-6 col-sm-6 col-xs-12">';
                                              element += '<select  id="item_id" name="item_id[]" class="form-control item_id"  required="required">';
                                              element += div_data;
                                              element += '</select>';
                                              element += ' <span class="text-danger"><?php echo form_error('item_id'); ?></span>';
                                              element += '</div>';
                                              element += ' </div>';



                                              element += ' <div class="item form-group"> ';
                                              element += '<label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line('price'); ?></label>';
                                              element += '<div class="col-md-6 col-sm-6 col-xs-12">';
                                              element += ' <div class=""> ';
                                              element += '  <input  name="price[]" placeholder="" type="text" class="form-control " />';
                                              element += '</div>';
                                              element += '</div>';
                                              element += '</div>';



                                              element += ' <div class="item form-group"> ';
                                              element += '<label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $this->lang->line('quantity'); ?> <span class="required">*</span></label>';
                                              element += '<div class="col-md-6 col-sm-6 col-xs-12">';
                                              element += ' <div class=""> ';
                                              element += '  <input id="quantity" name="quantity[]" placeholder="" type="text" class="form-control "  value="<?php echo isset($_POST['quantity']) ?  $_POST['quantity'] : ''; ?>" required="required" />';
                                              element += '<div class="div_avail">';
                                              element += ' <span>Available Quantity : </span>';
                                              element += ' <span class="item_available_quantity">0</span>';
                                              element += '</div>';
                                              element += '</div>';
                                              element += ' <div class="help-block"><?php echo form_error('quantity'); ?></div>';
                                              element += '</div>';
                                              element += '</div>';


                                          
                                              // element += '<button class="btn btn-primary remove" >-</button>'
                                              element += '</div>';


                                              $('#addCommissionForm').append(element);


                                              

                                    });


                                $(form_id+'.item_id').append(div_data);
                              },
                            })


                        });


                         


                    }

                });
            }
        }
		$(document).on('change', '#item_category_id', function (e) {
            $(form_id+'#item_id').html("");
            var item_category_id = $(this).val();
            populateItem(0, item_category_id);
        });


         
          $(document).on('click', '.remove', function() {
              $(this).parent().parent().remove();
            });



        $(document).on('change', '#item_id', function (e) {
        $('.div_avail').hide();
        var item_id = $(this).val();
        availableQuantity(item_id);

    });

	function availableQuantity(item_id) {
        if (item_id != "") {
            $('.item_available_quantity').html("");
            var div_data = '';
            $.ajax({
                type: "GET",
                url: base_url + "item/getAvailQuantity",
                data: {'item_id': item_id},
                dataType: "json",
                success: function (data) {

                    $('.item_available_quantity').html(data.available);
                    $('.div_avail').show();
                }

            });
        }
    }
	
			 var date_format = '<?php echo $result    = strtr('m/d/Y', ['d' => 'dd', 'm' => 'mm', 'Y' => 'yyyy']) ?>';
       var date_format_js = '<?php echo $result = strtr('m/d/Y', ['d' => 'dd', 'm' => 'MM', 'Y' => 'yyyy']) ?>';        
		$('.date').datepicker({
            format: date_format,

             autoclose: true,
                language: '<?php echo $language_name ?>'
        });
          $('#datatable-responsive').DataTable( {
              dom: 'Bfrtip',
              iDisplayLength: 15,
              buttons: [
                  'copyHtml5',
                  'excelHtml5',
                  'csvHtml5',
                  'pdfHtml5',
                  'pageLength'
              ],
              search: true,              
              responsive: true
          });
        });
		$('.fn_school_id').on('change', function(){
			 var school_id = $(this).val();
			var user_type=$("#issue_type").val();
			var category_id = '';
       
			getIssueUser(user_type);
			if(!school_id){
           toastr.error('<?php echo $this->lang->line('select'); ?> <?php echo $this->lang->line('school'); ?>');
           return false;
        }
       
       $.ajax({       
            type   : "POST",
            url    : "<?php echo site_url('ajax/get_itemcategory_by_school'); ?>",
            data   : { school_id:school_id, category_id:category_id},               
            async  : false,
            success: function(response){                                                   
               if(response)
               {                     
                       $('#item_category_id').html(response);   
                   
               }
            }
        });
			
		});
    function getIssueUser(usertype) {
        $('#issue_to').html("");
		var school_id=$("#add_school_id").val();
        var div_data = "";
		if(school_id!='' && usertype!= ''){	
        $.ajax({
            type: "POST",
            url: base_url + "issueitem/getUser",
            data: {'usertype': usertype,'school_id':school_id},
            dataType: "json",
            success: function (data) {

                $.each(data.result, function (i, obj)
                {
                    //if (data.usertype == "admin") {
                        name = obj.username;
                    //} else {
                     //   name = obj.name+" "+obj.surname+" ("+obj.employee_id+")";

                    //}
                    div_data += "<option value=" + obj.id + ">" + name + "</option>";
                });
                $('#issue_to').append(div_data);
            }

        });
		}
    }
       $("#add").validate();  
       $("#edit").validate();  
	   function get_itemissue_by_school(url){          
        if(url){
            window.location.href = url; 
        }
    } 
</script>