<br>
    <div class="item1 form-group">
            
            <div class="item1 form-group">                        
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">EMI Type <span class="required">*</span></label>
                           <div class="col-md-6 col-sm-6 col-xs-12">
                                <select  id="emi_type" name="emi_type" class="form-control item_id"  required='required'>
                                <option value="">--<?php  echo $this->lang->line('select') ?>--</option>
                                </select>
                                
                           </div>
           </div>
   
         
     </div>  
 <br>   
   
   
          